# TODO List

* [ ] Add a *"hackban"* command (ban a user by ID from a guild without him being in it)
* [ ] Add a basic slur word filter
* [ ] Add a code of conduct for the repository
* [ ] Add a lock command that will let administrators temporary lock a channel, useful in case of a raid
* [ ] Add an archive command that lets administrators archive a text channel in a text file
* [ ] Add an issue and pull request template for the repository
* [X] Be able to save data to JSON (blacklist, owners, etc.)
* [X] Move config to JSON